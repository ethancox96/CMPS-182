SELECT licenseid, name, birthdate
FROM Drivers
WHERE eyecolor = 'BRN' AND haircolor = 'BLK';
