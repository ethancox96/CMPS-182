SELECT DISTINCT Model, year 
FROM Vehicles, Drivers
WHERE name = 'John Smith';
