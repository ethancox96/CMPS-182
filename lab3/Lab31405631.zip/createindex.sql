CREATE INDEX VehicleIndex ON Vehicles(Model, Year);
