import java.sql.*;
import java.util.*;

/**
 * The class implements methods of the DMV database interface.
 *
 * All methods of the class receive a Connection object through which all
 * communication to the database should be performed. Note: the
 * Connection object should not be closed by any method.
 *
 * Also, no method should throw any exceptions. In particular, in case
 * that an error occurs in the database, then the method should print an
 * error message and call System.exit(-1);
 */
public class DMVApplication {

    private Connection connection;
    
    /*
     * Constructor
     */
    public DMVApplication(Connection connection) {
        this.connection = connection;
    }
    
    public Connection getConnection()
    {
        return connection;
    }
    
     /**
     * Return list of DriverID values for drivers who own at least numberOfVehicles vehicles.
     */
    public List<Integer> getDriversWithManyVehicles(int numberOfVehicles)
    {
    List<Integer> result = new ArrayList<Integer>();
    // your code here
    
    
    
    // end of your code
    return result;
    }
    
    
    /**
     * Takes as input a name and address, and a TicketID, and changes the DriverID on the ticket to the DriverId 
     * of the driver who has the specified name and address.  Since (name, address) is UNIQUE in Drivers, 
     * there can’t be multiple Drivers with that name.  
     * If there are no people with that name and address,setTicketedDriver should do nothing. 
     * If there is no ticket with the specified TicketId, setTicketedDriver should also do nothing.
     * setTicketedDriver should be performed as a single SQL statement.
     */
    public void setTicketedDriver(String name, String address, int ticketID) {
        // your code here
        
        
        

        // end of your code
    }
    
    
    /**
     * The getSomeTicketFees method takes as input an integer, stopTotal. getSomeTicketFees should
     * iterate through all the tickets whose Fee isn’t NULL in ascending TicketDate order, gathering their
     * TicketID.  getSomeTicketFees should total the fees on those tickets as it goes.  When
     * the total of the fees is more than stopTotal, then the method is finished; it should not 
     * look at or gather any more tickets.  If the total of the fees isn’t more than stopTotal 
     * but there are no more tickets to gather, then the method also should finish.
     * getSomeTicketFees should return all the TicketID values that it found,     *
     * If stopTotal is not positive, then getSomeTicketFees should do nothing.  
     * Note that the Fee on a ticket can be NULL, but TicketDate can’t be NULL.
     */
    public List<Integer> getSomeTicketFees(int stopTotal)
    {
    List<Integer> result = new ArrayList<Integer>();
    {
        // your code here
        
        
        // end of your code       
    }

};
